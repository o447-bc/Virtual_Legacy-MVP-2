import json
import boto3
import urllib.parse
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('allQuestionDB')
s3 = boto3.client('s3')

def process_single_file(bucket, key):
    """Process a single JSON file from S3"""
    category = key.split('/')[-1].replace('.json', '')
    print(f"Processing file: s3://{bucket}/{key}, category: {category}")
    
    response = s3.get_object(Bucket=bucket, Key=key)
    body = response['Body'].read().decode('utf-8')
    data = json.loads(body)
    
    with table.batch_writer() as batch:
        items = data if isinstance(data, list) else [data]
        for item in items:
            item['questionType'] = category
            
            question_id = None
            if 'questionId' in item:
                question_id = int(item['questionId'])
            else:
                first_key = next(iter(item.keys()))
                question_id = int(item[first_key])
                
            item['questionId'] = question_id
            
            if question_id is None or question_id == "":
                raise ValueError(f"Cannot determine questionId for item: {item}")
                
            batch.put_item(Item=item)
    
    return len(items if isinstance(data, list) else [data])

def lambda_handler(event, context):
    try:
        print(f"Received event: {json.dumps(event)}")
        
        # Check if this is a manual trigger to process all files
        if 'processAll' in event and event['processAll']:
            bucket = event.get('bucket', 'virtual-legacy')
            prefix = event.get('prefix', 'questions/questionsInJSON/')
            
            response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
            
            if 'Contents' not in response:
                return {
                    'statusCode': 200,
                    'body': json.dumps('No files found')
                }
            
            json_files = [obj['Key'] for obj in response['Contents'] 
                         if obj['Key'].endswith('.json')]
            
            total_items = 0
            processed_files = []
            
            for file_key in json_files:
                try:
                    items_count = process_single_file(bucket, file_key)
                    total_items += items_count
                    processed_files.append(file_key)
                except Exception as e:
                    print(f"Error processing {file_key}: {str(e)}")
            
            return {
                'statusCode': 200,
                'body': json.dumps(f'Processed {len(processed_files)} files, {total_items} total items')
            }
        
        else:
            # Normal S3 event processing
            bucket = event['Records'][0]['s3']['bucket']['name']
            key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
            
            items_count = process_single_file(bucket, key)
            
            return {
                'statusCode': 200,
                'body': json.dumps(f'Successfully processed {key}, {items_count} items')
            }
    
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        print(f"ClientError: {error_code} - {error_message}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'ClientError: {error_code} - {error_message}')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }