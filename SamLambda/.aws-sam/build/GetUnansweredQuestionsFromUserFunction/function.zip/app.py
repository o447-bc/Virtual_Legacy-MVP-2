import json
import boto3
import sys
import os
from botocore.exceptions import ClientError

# Temporarily disable persona validation
# from shared.persona_validator import PersonaValidator

def lambda_handler(event, context):
    # Extract parameters from the event
    thisQuestionType = None
    thisUserId = None
    
    # Check query string parameters
    if event.get('queryStringParameters'):
        thisQuestionType = event['queryStringParameters'].get('questionType')
        thisUserId = event['queryStringParameters'].get('userId')
    # Check direct event parameters
    else:
        thisQuestionType = event.get('questionType')
        thisUserId = event.get('userId')
    
    if not thisQuestionType or not thisUserId:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'GET,OPTIONS'
            },
            'body': json.dumps({
                'error': 'Missing required parameters: questionType and userId'
            })
        }
    
    # Temporarily disable persona validation
    try:
        validate_user_access(thisUserId)
        validQuestionIds = get_unanswered_questions(thisQuestionType, thisUserId)
        
        # Create response
        response_body = {'unansweredQuestionIds': validQuestionIds}
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'GET,OPTIONS'
            },
            'body': json.dumps(response_body)
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'GET,OPTIONS'
            },
            'body': json.dumps({
                'error': f"Error accessing DynamoDB: {str(e)}"
            })
        }

def validate_user_access(userId):
    """Validate that the user can only access their own partition in userQuestionStatusDB.
    
    Args:
        userId (str): The user ID to validate
        
    Raises:
        ValueError: If userId is invalid or access is denied
    """
    if not userId or not isinstance(userId, str) or len(userId.strip()) == 0:
        raise ValueError("Invalid userId provided")

def get_unanswered_questions(thisQuestionType, thisUserId):
    """Get question IDs that match the question type and are not yet answered by the user.
    
    Args:
        thisQuestionType (str): The type of questions to retrieve
        thisUserId (str): The user ID to check against
        
    Returns:
        list: List of question IDs that are valid and not yet answered by the user
    """
    # Initialize DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    question_table = dynamodb.Table('allQuestionDB')
    user_status_table = dynamodb.Table('userQuestionStatusDB')
    
    # 1. Get all valid questions of the specified type from allQuestionDB
    validQuestionIds = []
    question_response = question_table.scan(
        FilterExpression='Valid = :valid AND questionType = :qType',
        ExpressionAttributeValues={
            ':valid': 1,
            ':qType': thisQuestionType
        }
    )
    
    # Extract just the questionId values
    for item in question_response['Items']:
        if 'questionId' in item:
            validQuestionIds.append(item['questionId'])
    
    # Handle pagination if necessary
    while 'LastEvaluatedKey' in question_response:
        question_response = question_table.scan(
            FilterExpression='Valid = :valid AND questionType = :qType',
            ExpressionAttributeValues={
                ':valid': 1,
                ':qType': thisQuestionType
            },
            ExclusiveStartKey=question_response['LastEvaluatedKey']
        )
        for item in question_response['Items']:
            if 'questionId' in item:
                validQuestionIds.append(item['questionId'])
    
    # 2. Get all answered questions for this user from userQuestionStatusDB with the specified question type
    currAnsweredQuestions = []
    user_response = user_status_table.query(
        KeyConditionExpression='userId = :uid',
        FilterExpression='questionType = :qType',
        ExpressionAttributeValues={
            ':uid': thisUserId,
            ':qType': thisQuestionType
        }
    )
    
    # Extract just the questionId values
    for item in user_response['Items']:
        if 'questionId' in item:
            currAnsweredQuestions.append(item['questionId'])
    
    # Handle pagination if necessary
    while 'LastEvaluatedKey' in user_response:
        user_response = user_status_table.query(
            KeyConditionExpression='userId = :uid',
            FilterExpression='questionType = :qType',
            ExpressionAttributeValues={
                ':uid': thisUserId,
                ':qType': thisQuestionType
            },
            ExclusiveStartKey=user_response['LastEvaluatedKey']
        )
        for item in user_response['Items']:
            if 'questionId' in item:
                currAnsweredQuestions.append(item['questionId'])
    
    # 3. Remove answered questions from valid questions
    unanswered_question_ids = [qid for qid in validQuestionIds if qid not in currAnsweredQuestions]
    
    return unanswered_question_ids